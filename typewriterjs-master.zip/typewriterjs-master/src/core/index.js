import 'core-js/modules/es.array.is-array';
export { default } from './Typewriter';